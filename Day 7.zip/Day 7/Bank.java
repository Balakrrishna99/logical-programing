class bank
name 
acctype
anco