class Student 
{
    final int rollno=123
}
class Rollno
{
    public static void main(String args[])
    {
         
        System.out.println("Student Rollno is:");
    
}