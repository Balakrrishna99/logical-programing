import jav.util.*;
class Employee
{
    int id;
    String name;
    String dept;
    int salary;
    String address;
    Employee(int id,String name,String dept,int salary,String address)
    {
        id=i;
        name=n;
        dep=d;
        salary=s;
        address=a;
    }
    employee()
    {
        
    }
    employee(int i)
    {
        id=i;
    }
    void display()
    {
        System.out.ptintln(id+"\n"+nmae+"\n"+dep+"\n"+salary+"\n"+address);
    }
    void reading()
    {
        System.out.println(name+"reading");
    }
    void Working()
    {
        System.out.println(name+"working");
    }
}
class EmployeeInfo
{
    public static void main(String args[])
    {
        employee e1=new employee(49,"Bala Krrishna","Civil Engineering","Royal","35000","Vijayawada");
        System.out.println("employee 1 information");
        e1.display();
        e1.reading();
        e1.working();
    }
}