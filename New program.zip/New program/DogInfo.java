class Dog
{
    String name;
    String color;
    String bread;
    String eyecolor;
    
    void bark()
    {
        System.out.println(name+"barking");
    }
    void eat()
    {
        System.out.println(name+"eating");
    }
}
class DogInfo
{
    public static void main(String args[])
    {
        Dog dog1=new Dog();
        dog1.name=puppy;
        dog1.color=browm;
        dog1.bread=siberianhusky;
        dog1.eyecolor=blue;
        
        System.out.println("Dog 1 information");
        System.out.println(dog1.name+dog1.color+dog1.bread+dog1.eyecolor);
        dog1.barking();
        dog1.eating();
        
        Dog dog2=new Dog();
        dog2.name=ginger;
        dog2.color=black;
        dog2.bread=weimaraner;
        dog2.eyecolor=black;
        
        System.out.println("Dog 2 information");
        System.out.println(dog2.name+dog2.color+dog2.bread+dog2.eyecolor);
        dog2.barking();
        dog2.eating();
    }
}