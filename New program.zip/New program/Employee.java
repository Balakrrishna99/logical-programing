class Employee
{
    int id;
    String name;
    String dept;
    int salary;
    String address;
    
    void Total salary()
    {
        System.out.println(name+"Gross salary = Salary+HDR+DA");
    }
    //based on
    
    if salary>10000 to 20000
    HDR is 20%
    gross salary 
}
class Employee
{
    public static void main(String args[])
    {
        Employee Emp1=new Employee();
        emp1.id=1234;
        emp1.nmae="Siri";
        emp1.dep="it software";
        emp1.salary=35000;
        emp1.address="Vijayawada";
        
        System.out.print
    }
}