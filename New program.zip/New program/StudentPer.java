class Student 
{
    String name;
    int rollno;
    String sec;
    int internal_marks;
    int external_marks;
    int project_marks;
    
    void grade()
    {
        int per;
        int total=internal_marks+external_marks+project_marks;
        per=(total/300)*100;
      {
    
        if(per>=80)
        {
            System.out.print("A");
        }
        else if(per>=60 && per<80)
        {
           System.out.print("B");
        } 
        else if(per>=40 && per<60)
        {
            System.out.print("C");
        }
        else
        {
            System.out.print("Fail");
        }
        
      }
    }    
}
class StudentPer
{
    public static void main(String args[])
    {
        Student per1=new Student();
        per1.name=Bala;
        per1.rollno=49;
        per1.sec=A;
        per1.internal_marks=89;
        per1.external_marks=95;
        per1.project_marks=93;
        System.out.println("Total Percentage of per1");
        System.out.println(per1.name+per1.rollno+per1.sec+per1.internal_marks+per1.external_marks+per1.project_marks);
        pre1.grade();
        
        Student per2=new Student();
        per2.name=Krrishna;
        per2.rollno=51;
        per2.sec=A;
        per2.internal_marks=98;
        per2.external_marks=75;
        per2.project_marks=84;
        System.out.println("Total Percentage of per2");
        System.out.println(per2.name+per2.rollno+per2.sec+per2.internal_marks+per2.external_marks+per2.project_marks);
        per2.per();
        
    }
}